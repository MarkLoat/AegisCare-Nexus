import bcrypt from "bcryptjs";
import session from "express-session";
import connectPg from "connect-pg-simple";
import type { Express, Request, Response, NextFunction } from "express";
import { storage } from "./storage";
export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions",
  });
  return session({
    secret: process.env.SESSION_SECRET || "your-secret-key-change-in-production",
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: sessionTtl,
    },
  });
}
export async function hashPassword(password: string): Promise<string> {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
}
export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return await bcrypt.compare(password, hashedPassword);
}
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (req.session && req.session.adminId) {
    return next();
  }
  return res.status(401).json({ message: "Authentication required" });
}
export function isAuthenticated(req: Request): boolean {
  return !!(req.session && req.session.adminId);
}
export async function getCurrentAdmin(req: Request) {
  if (!req.session?.adminId) {
    return null;
  }
  return await storage.getAdminUser(req.session.adminId);
}
declare module "express-session" {
  interface SessionData {
    adminId?: number;
  }
}
